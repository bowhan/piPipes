This repository is maintained solely for historical purposes.

Bedtools is now maintainted in the following repository: https://github.com/arq5x/bedtools2



